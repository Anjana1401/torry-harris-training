package com.torryharris.entiretrainreservationprojectspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntireTrainReservationProjectSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
